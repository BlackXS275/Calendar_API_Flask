class Event():
    id: str
    date: str
    title: str
    text: str